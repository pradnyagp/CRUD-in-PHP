<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

* {box-sizing: border-box;}

body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .header-right {
    float: none;
  }
</style>
</head>
<body>
<div class="header">
  <a href="#default" class="logo">Adroid</a>
  <div class="header-right">
    <a class="active" href="#home">Home</a>
    <a href="#contact">Contact</a>
    <a href="#about">About</a>
  </div>
</div>

<h2>USERS</h2>

<table>
<thead>
            <tr>
                <th>id</th>
                <th>Name</th>
                <th>DOB</th>
                <th>Mobile</th>
                <th>Adress</th>
                <th>User Role</th>
                <th>Activation status</th>
                <th>User creation date</th>
            </tr>
        </thead>
<tbody>
            <?php foreach ($data as $record){?>
                <tr>
                    <td><?php echo $record['id'];?></td>
                    <td><?php echo $record['name'];?></td>
                    <td><?php echo $record['dob'];?></td>
                    <td><?php echo $record['mobile'];?></td>
                    <td><?php echo $record['address'];?></td>
                    <td><?php echo getuserRole($record['user_role']);?></td>
                    <td><?php echo getuserStatus($record['status']);?></td>
                    <td><?php echo $record['created_datetime'];?></td>
                </tr>
            <?php }?>
        </tbody>
  
</table>

</body>
</html>
