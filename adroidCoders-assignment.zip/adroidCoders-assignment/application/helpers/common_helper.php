<?php 
    function getuserRole($role_id){
        if($role_id == 1){
            return 'Admin User';
        }else{
            return 'Normal User';
        }
    }

    function getuserStatus($status_id){
        if($status_id == 1){
            return 'Active';
        }else{
            return 'In-Active';
        }
    }