<?php
defined('BASEPATH') OR exit('No direct script access allowed');

///user_model having common functions
class Dashboard extends User_model {


    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Dashboard_model');
    }

    //default login
    function index(){

    }

}