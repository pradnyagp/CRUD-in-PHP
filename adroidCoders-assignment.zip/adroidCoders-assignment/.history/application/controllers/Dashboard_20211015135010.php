<?php
defined('BASEPATH') OR exit('No direct script access allowed');

///user_model having common functions
class Dashboard extends User_model {


    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Dashboard_model');
        if(empty($_SESSION['logged_id'])){
            redirect('')
        }
    }

    //Post login default view
    function index(){

        
    }

}