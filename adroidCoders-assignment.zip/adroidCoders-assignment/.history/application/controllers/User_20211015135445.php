<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {


    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('User_model');
    }
	
    /**
     * Load defailt login page
     */
	public function index()
	{
		$this->load->view('login');
	}

    /**
     * Reset password page redirection
     */
    function resetLogin(){
        $this->load->view('reset_password');
    }

    /**
     * accept username and password and authenticate the user 
     * index.php has been added intentially because in a mac machine once the update .htaccess then need to restart the machine 
     * and if machine goes restart then need to join same call again
     */
    function login(){
        //CI library to validate the form input data
        $this->load->library('form_validation');

        $inputData = $this->input->post();
        if(!empty($inputData['uname']) && !empty($inputData['psw'])){

            //as per time concern using MD5 algo to encrypt the password
            $password = md5($inputData['psw']);
            //validate username and password
            //status = 1 user is active
            //status = 0  user is in-active
            $validateData = $this->User_model->select_single('user_name, id, user_role', array('user_name' => $inputData['uname'], 'password'=>$password, 'status'=>'1'), 'user');
            if($validateData){
                //load session
                $this->load->library('session');
                $setSessionData = array(
                    'logged_id' => $validateData['id'],
                    'user_name' => $validateData['user_name'],
                    'user_role' => $validateData['user_role']
                );
                $this->session->set_userdata($setSessionData);
                //authenticate successfully
                redirect('index.php/dashboard');
            }else{
                $this->session->set_flashdata('message_name', 'Username or password not captured correctly.');
            }
            
        }else{
            //redirect on home page 
            $this->session->set_flashdata('message_name', 'Username or password not captured correctly.');

            redirect('');
        }
        
    }
}
