<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {


    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('User_model');
        // $this->load->library('session');
    }
	
    /**
     * Load defailt login page
     */
	public function index()
	{
		$this->load->view('login');
	}

    /**
     * Reset password page redirection
     */
    function resetLogin(){
        $this->load->view('reset_password');
    }

    /**
     * accept username and password and authenticate the user 
     * index.php has been added intentially because in a mac machine once the update .htaccess then need to restart the machine 
     * and if machine goes restart then need to join same call again
     */
    function login(){
        $inputData = $this->input->post();
        if(!empty($inputData['uname']) && !empty($inputData['psw'])){

            //validate username and password
            $this->User_model->select_single('username, password, status', array('username' => $inputData['uname'], ))

        }else{
            //redirect on home page 
            $this->session->set_flashdata('message_name', 'Username or password not captured correctly.');

            redirect('');
        }
        
    }
}
