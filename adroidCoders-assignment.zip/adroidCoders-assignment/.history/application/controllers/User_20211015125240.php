<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
    }
	
	public function index()
	{
		$this->load->view('login');
	}

    function resetLogin(){
        $this->load->view('reset_password');
    }

    function login(){
        $inputData = $this->input->post();
        print_r($inputData);die;
    }
}
