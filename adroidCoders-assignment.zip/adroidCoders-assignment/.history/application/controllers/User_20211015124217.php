<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        //ini_set('display_errors', 1);
        $this->load->helper('edu');
//        if ($this->sessionData === FALSE) {
//            redirect('login');
	    //echo '';
//        }
    }
	
	public function index()
	{
		$this->load->view('login');
	}

    function resetLogin(){
        $this->load->helper('url');
        $this->load->view('login');
    }
}
