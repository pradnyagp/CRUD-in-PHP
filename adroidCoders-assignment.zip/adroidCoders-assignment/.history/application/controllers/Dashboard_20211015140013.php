<?php
defined('BASEPATH') OR exit('No direct script access allowed');

///user_model having common functions
class Dashboard extends CI_Controller {


    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        //$this->load->model('Dashboard_model');
        $this->load->model('User_model');

        //this controller is fully secured with session
        if(empty($_SESSION['logged_id'])){
            $this->session->set_flashdata('message_name', 'Username or password not captured correctly.');
            redirect('');
        }
    }

    //Post login default view
    function index(){
        $this->
        $this->load->view('Dashboard');
        
    }

}