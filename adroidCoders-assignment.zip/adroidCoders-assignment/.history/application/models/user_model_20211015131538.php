<?php

(defined('BASEPATH')) OR exit('No direct script access allowed');

class User_model extends CI_Model {

    //this kind of 
    function select_single($select, $where, $table) {
        if (!empty($select)) {
            $this->db->select($select);
        }

        if (!empty($where)) {
            $this->db->where($where);
        }

        return $this->db->get($table)->row_array();
    }
}