<?php

(defined('BASEPATH')) OR exit('No direct script access allowed');

class User_model extends CI_Model {

    function select_single($select, $where, $table) {
        //       $this->db->start_cache();
                if (!empty($select)) {
                    $this->db->select($select);
                }
        
        //        $this->db->get_compiled_select($table, TRUE);
        //        $this->db->stop_cache();
        
                if (!empty($where)) {
                    $this->db->where($where);
                }
        
                return $this->db->get($table)->row_array();
            }
}